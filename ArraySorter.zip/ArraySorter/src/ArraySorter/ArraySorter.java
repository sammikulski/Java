package ArraySorter;

import java.util.Arrays;

/**
 *
 * @author sammikulski
 */
public class ArraySorter {

    public static void selectionSort(int[] anArray) {
        for (int index = 0; index < anArray.length - 1; index++) {
            // Place the correct value in anArray[index]
            int indexOfNextSmallest = getIndexOfSmallest(index, anArray);
            interchange(index, indexOfNextSmallest, anArray);
            //Assertion:anArray[0] <= anArray[1] <=...<= anArray[index]
            //and these are the smallest of the original array elements.
            //The remaining positions contain the rest of the original
            //array elements.
        }
    }
    
    
    /**
    Returns the index of the smallest value in the portion of the
    array that begins at the element whose index is startIndex and
    ends at the last element.
	 */
   private static int getIndexOfSmallest(int startIndex, int[] a)
	{
		int min = a[startIndex];   
		int indexOfMin = startIndex;
		for (int index = startIndex + 1; index < a.length; index++)
		{
			if (a[index] < min)
			{
				min = a[index];
				indexOfMin = index;
				//min is smallest of a[startIndex] through a[index]
			}
		}
		return indexOfMin;
	}
    /**
    Precondition: i and j are valid indices for the array a.
    Postcondition: Values of a[i] and a[j] have been interchanged.
	 */
    private static void interchange(int i, int j, int[] a) {
        int temp = a[i];
        a[i] = a[j];
        a[j] = temp; //original value of a[i]
        System.out.println(Arrays.toString(a));
    }
    /*
    first and second elements are compared and swapped if out of order  
    then the second and third elements are compared and swapped if out of order, and so on. 
    continues until the last two elements of the array are compared and swapped if out of order.
    
    */
    public static int[] bubbleSort(int[] a) {
        boolean value = true;
        while (value) {
            value = false;
            for (int index = 0; index < a.length - 1; index++) {
                if (a[index] > a[index + 1]) {
                    int temp = a[index];
                    a[index] = a[index + 1];
                    a[index + 1] = temp;
                    value = true;
                }
            }
        }
        return a;
    }

/*
    as each element is looked at, it organizes them
    in order as it looks at each element in the array, organizes it
    just like one organizes their hand of cards in a card game
*/
    
    public static int[] insertionSort(int[] a) {
        for (int i = 0; i < a.length; i++) {
            int temp = a[i];
            int j;
            for (j = i - 1; j >= 0 && temp < a[j]; j--) {
                a[j + 1] = a[j];
            }
            a[j + 1] = temp;
        }
        return a;
    }

    public static void main(String[] args) {

        int[] set1 = {20, -13, 6, 1, 2, 88};
        int[] set2 = {33, 16, 1, 12, 8, -30};
        int[] set3 = {-9, 73, 6, 17, 21, 49};
        System.out.println("Set 1 :" + Arrays.toString(set1));
        interchange(0,3,set1);
        
        System.out.println("The smallest number is at index: "+ getIndexOfSmallest(0, set1));
        
        System.out.println(Arrays.toString(insertionSort(set1)));

        System.out.println("Set 2: "+ Arrays.toString(set2));
        selectionSort(set2);
        System.out.println("Set 3: "+ Arrays.toString(set3));
        System.out.println(Arrays.toString(bubbleSort(set3)));
    }
}


