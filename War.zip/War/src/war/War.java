package war;
/**
 *
 * @author sammikulski
 */
public class War {

    public static void main(String[] args) {
        String encryptedMessage = ":mmZ\\dxZmx]Zpgy"  ;
        String decryptedString ;
        int length = encryptedMessage.length();

        for (int key = 0; key <= 100; key++) {
            String decryptedMessage = "";
            for (int x = 0; x <= length - 1; x++ ) {
                int encrypted = encryptedMessage.charAt(x);
            if (encrypted - key < 32 ) {
                int decrypted = ((encrypted - key) + 127) -32;
                char decryptedChar= (char) decrypted;
                decryptedString = Character.toString(decryptedChar);
                decryptedMessage = decryptedMessage + decryptedString;
            } else {
                int decrypted = (encrypted - key);
                char decryptedChar= (char) decrypted;
                decryptedString = Character.toString(decryptedChar);
                decryptedMessage = decryptedMessage + decryptedString;
            }
            
            }
                System.out.println ("Key: " + key + " is: " + decryptedMessage);
                
            }
            }
                }
    
        
    
    
