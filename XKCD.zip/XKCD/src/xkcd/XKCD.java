package xkcd;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 *
 * @author sammikulski
 */
public class XKCD {

    public static String downloadURL;
    public static String imagelink;

    //this method is called in reader method
    //checks to see if URL is a vaild string
    public boolean checkString(String site) {
        String title = "title";
        String image = "<img src";
        if (site.contains(title) && (site.contains(image))) {
            this.downloadURL = site;

            return true;
        } else {
            return false;
        }
    }
    
    //method to include buffered reader - reads the characters of the basicLink
    //must include exception when using buffered reader
    
    public void reader(int i) throws Exception{
        String inputLine;
        URL basicLink = new URL("https://www.xkcd.com/" + i);
        BufferedReader stream = new BufferedReader(new InputStreamReader(basicLink.openStream()));

        while ((inputLine = stream.readLine()) != null) {
            checkString(inputLine);
        }
        stream.close();
    }

    //includes for loop to get 1st 100 pictures
    //checks characters
    public void getlink() {
        boolean x = true;
        while (x) {
            for (int k = 0; k < 100; k++) {
                if (XKCD.downloadURL.charAt(k + 11) == '"') {
                    imagelink = (downloadURL.substring(10, 11 + k));
                    x = false;
                    break;
                }
            }
        }
    }

    public static void main(String[] args) throws Exception {
        XKCD newDownload = new XKCD();
        for (int k = 1; k <= 100; k++) {
            newDownload.reader(k);
            newDownload.getlink();
            String urlToGet = "https:" + newDownload.imagelink;
            System.out.println(urlToGet);
            URL imageURL = new URL(urlToGet);
            InputStream imgStream = imageURL.openStream();
            Files.copy(imgStream, Paths.get("Image" + k + ".jpg"));
        }
    }
}
