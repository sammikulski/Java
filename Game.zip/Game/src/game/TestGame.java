
package game;

import java.util.Scanner;

/**
 *
 * @author tug41822
 */
public class TestGame {
    
    public static void main (String[] args) {
        Scanner input = new Scanner (System.in);
        
        Game game1 = new Game ("Who was the 40th president of the United States" , "Ronald Reagan");
        System.out.println("Who was the 40th president of the United States?");
        game1.checkAnswer(input.nextLine());
    
        
        Game game2 = new Game ("What is his wife's name?" , "Nancy" );
        System.out.println("What is his wife's first  name?");
        game2.checkAnswer(input.nextLine());
        
        System.out.println ("Thank you for playing!");
        
    }
    }
            

