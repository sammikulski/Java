package game;

/**
 *
 * @author tug41822
 */
public class Game {
    
    private String question;
    private String answer;
    private String userAnswer;
 
    public Game (String question, String answer) {
        this.question = question;
        this.answer = answer;
    }

    public String getQuestion() {
        return question;
    }

    public String getAnswer() {
        return answer;
    }

    public void setUserAnswer(String userAnswer) {
        this.userAnswer = userAnswer;
    }
    public String getUserAnswer() {
        return userAnswer;
    }
    
    public boolean checkAnswer(String userAnswer) {
        if (userAnswer.equals(getAnswer()) ) {
            System.out.println ("Your answer is correct!");
            return true;
        }
        
        else {
            System.out.println("WRONG!!!!");
            System.out.println ("Beter Luck next Time!");
            System.exit(0);
            return false;
        }
    }
  
    
}
