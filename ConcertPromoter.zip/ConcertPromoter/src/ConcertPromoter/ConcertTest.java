
package ConcertPromoter;

import java.util.Scanner;

/**
 *
 * @author tug41822
 */
public class ConcertTest {
    
    public static void main (String[] args) {
        Scanner input = new Scanner (System.in);
        //Concert info
        ConcertPromoter Blink182 = new ConcertPromoter ("Blink-182", 50, 50.00, 62.00);
                                               //band name, capacity, phone price, venue price
        System.out.println (Blink182.getBandName() + " coming live to a city near you!");
        System.out.println("Tickets on sale now for $" + Blink182.getPhonePrice() + " over the phone or $" + Blink182.getVenuePrice() + " at the venue!");
        System.out.println("Only " + Blink182.getCapacity() + " tickets available!");
        
       
        System.out.println("Please enter the amount of tickets in an order");
        System.out.println("When you are done entering phone tickets, please enter '0'"); 
        
        //Phone sales
        while (Blink182.dayOfShow == false) {
        //Calculates number of tickets in each order
        //Adds to tickets sold, subtracts from capacity
        int tix = input.nextInt();
        if (tix >0) {
        Blink182.sellPhoneTickets(tix);
        System.out.println (Blink182.getPhoneTicketsSold() + " total tickets sold!");
        System.out.println("Only " + Blink182.getPhoneTicketsLeft() + " left to sell!");
        }
        if (tix == 0) {
            Blink182.dayOfShow(true);
        }

        }
        if (Blink182.dayOfShow == true) {
        System.out.println("It is now the day of the show! Prices have changed! A venue ticket costs: " + Blink182.getVenuePrice());
        System.out.println("Please enter the amount of tickets being purchased in an order");
            
        }
        while (Blink182.dayOfShow == true) {
        
        int tix = input.nextInt();
        if (tix >0) {
            Blink182.sellVenueTickets(tix);
        
        System.out.println ((Blink182.getVenueTicketsSold() + Blink182.getPhoneTicketsSold()) + " total tickets sold!");
        System.out.println("Only " + Blink182.getVenueTicketsLeft() + " left to sell!");
        }
        if (tix == 0) {
        System.out.println("A total of " + Blink182.getPhoneTicketsSold() +" phone tickets were sold");
        System.out.println("A total of " + Blink182.getVenueTicketsSold() +" venue tickets were sold");
        System.out.println("The total revenue from phone sales is: $" + Blink182.getPhoneSales());
        System.out.println("The total revenue from veneu sales is: $" + Blink182.getVenueSales());
        System.exit(0);
        }
        }

    }
}


        
    
           
