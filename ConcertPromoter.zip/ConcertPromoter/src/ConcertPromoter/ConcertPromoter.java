package ConcertPromoter;

/**
 *
 * @author tug41822
 */
public class ConcertPromoter {
    private String bandName;
    private int capacity;
    private double phonePrice;
    private int phoneTicketsSold;

    
    private double venuePrice;  
    private int venueTicketsSold;
    public boolean dayOfShow = false;
    
    
    
    public ConcertPromoter (String bandName, int capacity, double phonePrice, double venuePrice) {
        this.bandName = bandName;
        this.capacity = capacity;
        this.phonePrice = phonePrice;
        this.venuePrice = venuePrice;
    }

    public double getPhonePrice() {
        return phonePrice;
    }

    public double getVenuePrice() {
        return venuePrice;
    }

    public String getBandName() {
        return bandName;
    }
    public int getCapacity() {
        return capacity;
    }
    public int getPhoneTicketsSold() {
        return phoneTicketsSold;
    }

    public int getVenueTicketsSold() {
        return venueTicketsSold;
    }
    
    public void dayOfShow(boolean newStatus) {
            dayOfShow = newStatus;
        }
    
    
    public void sellVenueTickets(int numTicketsOrdered) {
        venueTicketsSold = venueTicketsSold + numTicketsOrdered;
    }
    public void sellPhoneTickets(int numTicketsOrdered) {
        phoneTicketsSold = phoneTicketsSold + numTicketsOrdered;
    }
    public int getVenueTicketsLeft() {
           return ((getPhoneTicketsLeft()) - venueTicketsSold);
    }
    public int getPhoneTicketsLeft(){
            return (capacity - phoneTicketsSold);
    }
    public double getVenueSales () {
        return (venueTicketsSold * venuePrice);
    }
    public double getPhoneSales() {
        return (phoneTicketsSold * phonePrice);
    }
    public double getTotalSales() {
        return (getVenueSales() + getPhoneSales());
    }
    
    
    
}
