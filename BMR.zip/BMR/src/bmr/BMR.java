package bmr;

import java.util.Scanner;

/**
 *
 * @author sammikulski
 */
public class BMR {

    public static void main(String[] args) {
        
    //Intro    
    System.out.println ("Welcome! This program will tell you your Basal Metabolic Rate,");
    System.out.println ("also known as your BMR. This formula lets you know how many calories");
    System.out.println ("should be consumed to maintain your current weight");
    System.out.println ();
        
    // Age, Height and Weight Input    
    Scanner input = new Scanner (System.in);
    System.out.println ("Please enter your age (in years):");
        int age = input.nextInt();
    System.out.println ("Please enter your height (in inches):");
        Double height = input.nextDouble();
    System.out.println ("Please enter your weight (in pounds):");
        int weight = input.nextInt();
        
    //Equations for BMR    
    double fBMR = 655.1 + (4.35 * weight) + (4.7 * height) - (4.7 * age);    
    double mBMR = 66 + (6.2 * weight) + (12.7 * height) - (6.76 * age);
    
    System.out.println ("If you are a male, your BMR is: " + mBMR + " calories");
    System.out.println ("If you are a female, your BMR is: " + fBMR + " calories");
    System.out.println ();
    
    //Equations for Chocolate Bars
    double maleChocolate = ((mBMR) / 214);
    double femaleChocolate =  ((fBMR) / 214);
    
    System.out.println ("If you are a male, you can eat around "+ maleChocolate + " chocolate bars a day");
    System.out.println ("If you are a female, you can eat around "+ femaleChocolate + " chocolate bars a day");
    
    
    
    
}
        
}
