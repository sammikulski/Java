
package ball;

import java.util.Scanner;


public class Ball {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    //variables (initial state)
    double height = 0;
    double velocity;
    int bounces = 0;
      
    System.out.println ("Please enter the initial velocity of the ball:");    
    Scanner input = new Scanner (System.in);
    
    velocity = Double.parseDouble ( input.nextLine() );
 
            for (int time = 0; bounces <=5; time++) 
            {
                if (time > 0) {
                    height = height + velocity;
                    velocity = velocity - 32.0;
                }
                if (height < 0) {
                    height = height * -0.5;
                    velocity = velocity * -0.5;
                    System.out.println("BOUNCE!");
                    bounces++;
                }
                System.out.println("Time: " + time + " " + "Height: " + height);
            }
            
}
}

