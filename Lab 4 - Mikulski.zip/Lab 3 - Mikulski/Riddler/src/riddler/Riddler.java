package riddler;

/**
 *
 * @author sammikulski
 */
public class Riddler {

   
public static void main(String[] args) {
 
   for (int x = 1000;  x<= 9999; x++) {
       int a = (x / 1000) % 10;
       int b = (x / 100) % 10;
       int c = (x / 10) % 10;
       int d = x % 10;
  
     //4 different digits
     if ( a!=b && a!=c && a!=d && b!=c && b!=d && c!=d ) {
         if (a == c * 3) {
             if (x % 2!=0) {
                 if (a + b + c + d == 27) {
                     System.out.println ("The riddler will strike at: " + a + b + c + d + " Pennsylvania Avenue");
                 }
             }
         }  
     }
   }
}
}
    
    
  
    

