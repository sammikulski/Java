
package triangle;

import java.util.Scanner;

/**
 *
 * @author sammikulski
 */
public class Triangle {

    public static void main(String[] args) {
        
    Scanner input = new Scanner (System.in);
    System.out.println("Please enter the size of a triangle (1-50) :");
    int size = Integer.parseInt( input.nextLine());
    
    
     if (size <0) {
       System.out.println("That is not in the range of 1-50!");
       System.exit(0);
    }
     if (size >50) {
       System.out.println("That is not in the range of 1-50!");  
       System.exit(0);
     }

    for ( int x = 0; x <= size; x ++) {
        
           for (int y = 0; y < x; y++) {
           System.out.print ("*");
    }
           System.out.println();
    }
    
    for ( int x = size - 1; x >=0; x --) {
           
           for (int y = 0; y < x; y++) {
               System.out.print ("*");
    }
           System.out.println();
    }
}
}
