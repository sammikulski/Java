package dateformat;

import java.util.Scanner;

/**
 *
 * @author sammikulski
 */
public class DateFormat {

    public static void main(String[] args) {
 
     Scanner input = new Scanner (System.in); 
     System.out.println ("Please enter the date in the mm/dd/yyyy format: ");
     String date = input.nextLine();
     
     String month = date.substring(0,2);
     String day = date.substring (3,5);
     String year = date.substring(6,10);
     
     System.out.println ("The month is: " + month);
     System.out.println ("The day is: " + day);
     System.out.println ("The year is: " + year);
     System.out.println ("");
     
     int m = Integer.parseInt(month); 
     int d = Integer.parseInt(day);
     int y = Integer.parseInt(year);
     
     
     
      if ((y % 4 == 0) && y % 100 != 0) {
    System.out.println ("It is a leap year!");
    System.out.println ("");
    
 }
 else if ((y % 4 == 0) && (y % 100 == 0) && (y % 400 == 0)) {
    System.out.println ("It is a leap year!");  
    System.out.println ("");
    }    
    else { 
System.out.println ("It is not a leap year!");
System.out.println ("");

}

     if (m > 0 && m <12) {
          System.out.println ("The month is valid");
    } else 
        System.out.println ("The month is not valid, please try again.");
      
    if (m==1 || m==3 | m ==5 || m==7 || m==8 || m==10 || m==12) {
        if (d >0 && d<=31) {
            System.out.println ("The day is valid");
        }
        else { System.out.println ("The date is invalid");
            System.out.println ("Your day is invalid");
        
    }
    }
    
    if (m==4 || m==6 | m ==9 || m==11) {
        if (d >0 && d<=30) {
            System.out.println ("The day is vaild");
        }
        else { System.out.println ("Your day is invalid");
    }
}
    if (m==2 && (d>0 && d<=28) ) {
                System.out.println ("The day is valid");
            } 
     System.out.println ("The year is valid");
    
    if (m==2 && (d>=29) ) {
         if ((y % 4 == 0) && y % 100 != 0) {
    System.out.println ("Your day is valid");
 }
 else if ((y % 4 == 0) && (y % 100 == 0) && (y % 400 == 0)) {
    System.out.println ("Your day is valid");
    }    
    else { 
    System.out.println ("Your day is invalid, It is not a leap year! ");

}
          
   
    } 


    }
}

    
    
    
    
  
     

