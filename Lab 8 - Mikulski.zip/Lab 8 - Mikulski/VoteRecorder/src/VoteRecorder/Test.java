/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VoteRecorder;

import java.util.Scanner;

/**
 *
 * @author sammikulski
 */
public class Test {
    
    public static void main(String[] args) {
    VoteRecorder.setPresident("Hillary Clinton", "Donald Trump" );
    VoteRecorder.setVicePresident("Tim Kaine", "Mike Pence" );
    VoteRecorder.resetVotes();
    
    boolean moreVotes = true;
    
    while (moreVotes){
            VoteRecorder newVoter = new VoteRecorder();
            newVoter.getAndConfirmVotes();
            System.out.println("Type yes if there is another voter");
            Scanner input = new Scanner(System.in);
            moreVotes = input.next().equals("yes");
    }
           System.out.println(VoteRecorder.getCurrentVotePresident());
           System.out.println(VoteRecorder.getCurrentVoteVicePresident());
    
}
}
