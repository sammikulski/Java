/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package VoteRecorder;

import java.util.Scanner;

/**
 *
 * @author sammikulski
 */
public class VoteRecorder {
    //Static variables to be used throughout the program
    private static String namePresident1;
    private static String namePresident2;
    private static String nameVicePresident1;
    private static String nameVicePresident2;
    private static int votesPresident1;
    private static int votesPresident2;
    private static int votesVicePresident1;
    private static int votesVicePresident2;
    private static int myVoteForPresident;
    private static int myVoteForVicePresident;
    

     // Returns myVoteForresident
    public int getMyVoteForPresident() { 
        return myVoteForPresident; 
    }
    
    // Returns myVoteForVicePresident
    public int getMyVoteForVicePresident() { 
        return myVoteForVicePresident; 
    }

    // Sets names of the presidents
    public static void setPresident(String name1, String name2) {
        namePresident1 = name1;
        namePresident2 = name2;
    }

    // Sets the names of the vice presidents
    public static void setVicePresident (String name1, String name2) {

        nameVicePresident1 = name1;
        nameVicePresident2 = name2;
    }
    
    // Resets vote counts to 0
    public static void resetVotes() {
        votesPresident1 = 0;
        votesPresident2 = 0;
        votesVicePresident1 = 0;
        votesVicePresident2 = 0;
    }
    //returns a string that tells how many votes each candidate for President has 
    public static String getCurrentVotePresident() {
        return namePresident1 + " has " + votesPresident1 + " votes\n" + namePresident2 +" has " + votesPresident2 + " votes";
    
}
    //returns a string that tells how many votes each candidate for Vice President has 
    public static String getCurrentVoteVicePresident() {
        return nameVicePresident1 + " has " + votesVicePresident1 + " votes\n" + nameVicePresident2 +" has " + votesVicePresident2 + " votes";
    
}
    //Records the vote for each voter, increments total number of votes for each candidate by 1
    public void recordVotes() {
        switch(myVoteForPresident){
            case 0: 
                break;
            case 1:
                votesPresident1++;
                break;
            case 2:
                votesPresident2++;
                break;      
        }
        switch(myVoteForVicePresident){
            case 0: 
                break;
            case 1:
                votesVicePresident1++;
                break;
            case 2:
                votesVicePresident2++;
                break;      
        }
    }
    //Voting process for voter to select candidate for President/Vice President
    private int getAVote(String name1, String name2) {
        Scanner input = new Scanner(System.in);
        int answer = 0;
        boolean good = false;
        while (!good) {
            System.out.println("Please select a candidate");
            System.out.println("0 - No One");
            System.out.println("1 - " +name1);
            System.out.println("2 - " +name2);
            answer = input.nextInt();
            good = answer>=0 && answer<=2;
            
        }
        return answer;   
    }
    
    private void getVotes() {
        System.out.println("You are voting for President: ");
        myVoteForPresident = getAVote(namePresident1, namePresident2);
        
        System.out.println("You are voting for Vice President: ");
        myVoteForVicePresident = getAVote(nameVicePresident1, nameVicePresident2);
    }
    //Asks voter to confirm their vote for each candidate
    private boolean confirmVotes() {
        System.out.println("Your vote for President is: ");
        switch (myVoteForPresident){
            case 0:
                System.out.println("No one");
                break;
            case 1:
                System.out.println(namePresident1);
                break;
            case 2:
                System.out.println(namePresident2);
                break;
        }
        System.out.println("Your vote for Vice President is: ");
         switch (myVoteForVicePresident){
            case 0:
                System.out.println("No one");
                break;
            case 1:
                System.out.println(nameVicePresident1);
                break;
            case 2:
                System.out.println(nameVicePresident2);
                break;
        }
        
        System.out.println("To confirm your vote, please type 'yes' ");
        Scanner input=new Scanner(System.in);
        return ( input.nextLine().equals("yes") );
        
    } 
    //Calls getVotes method, and confirmVotes methods, records final vote at the end
    public void getAndConfirmVotes() {
        boolean done = false;
                while(!done){
                    getVotes();
                    done=confirmVotes();
                }
                recordVotes();
    }

}


    
