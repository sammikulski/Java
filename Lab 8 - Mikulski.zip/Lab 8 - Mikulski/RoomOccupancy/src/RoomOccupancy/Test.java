package RoomOccupancy;

import java.util.Scanner;

/**
 *
 * @author sammikulski
 */
public class Test {
    
public static void main (String[] args) {    
    Scanner input = new Scanner (System.in);
    RoomOccupancy room1 = new RoomOccupancy();
    room1.addOneToRoom();
    room1.removeOneFromRoom();

    System.out.println("There are now: " + room1.getNumber() + " people in this room" );
}

}
