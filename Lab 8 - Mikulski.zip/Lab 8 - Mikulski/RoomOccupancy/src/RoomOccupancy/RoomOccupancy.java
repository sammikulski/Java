/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RoomOccupancy;

/**
 *
 * @author sammikulski
 */
public class RoomOccupancy {
    private int numberInRoom = 2;
    private static int totalNumber;
    
public void addOneToRoom () {
    numberInRoom +=1;
    totalNumber++;
}
public void removeOneFromRoom(){
    if (numberInRoom > 0) {
            numberInRoom -= 1;
            totalNumber--;
        } else
            System.out.println("That room is already empty!"); 
    }
public int getNumber(){
        return numberInRoom;
    }

    public static int getTotalNumber() {
        return totalNumber;

    }
}



