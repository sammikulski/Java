/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package firstapplication;

import java.util.Scanner;

/**
 *
 * @author sammikulski
 */
public class FirstApplication {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println ("Grace Hopper was an American Computer Scientist who served in the Navy during World War II.");
        System.out.println ("Before entering the war, she obtained a Ph.D. in Mathematics from Yale University.");
        System.out.println ("She was one of the first programmers of the Harvard Mark I computer.");
        Scanner reader = new Scanner (System.in);
        System.out.println ("Have you ever heard of Grace Hopper? (Please Enter Yes or No)");
        String response = reader.next();
        System.out.println (response);
        System.out.println ("I hope you learned something today!");
        
    }
    
}
