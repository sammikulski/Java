package Hangman;
import java.util.Scanner;

/**
 *
 * @author sammikulski
 */
public class Test2 {


    
public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Hangman hangman = new Hangman("funny"); // enter secret word as a string
        while (hangman.isFound()== false){
            System.out.println("The word is: " + hangman.getDisguisedWord());
            System.out.println("Guess a letter or type 'guesses' to see your guesses.");
            String guess = input.nextLine();
                if (guess.equalsIgnoreCase("guesses"))
                {
                    System.out.println(hangman.getGuessedLetters());
                }
                else
                {
                    hangman.makeGuess(guess.charAt(0));
                }
            }

            System.out.println("The secret word was: " + hangman.getSecretWord());
            System.out.println("It took you " + hangman.getNumberOfGuesses() + " guesses to get the correct answer.");
            System.out.println("You had " + hangman.getNumberOfIncorrectGuesses()+ " incorrect guesses.");
}
}

