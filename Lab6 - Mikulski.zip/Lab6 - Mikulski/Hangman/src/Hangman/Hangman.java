package Hangman;

/**
 *
 * @author sammikulski
 */
public class Hangman {

    /*
	 * Helper method that your professor wrote for you, 
	 * so you don't have to write it.
	 * It will help you for makeGuess(char c)
	 * 
	 * Given a string, an index in the String, and a character,
	 * this method will return a *new* String replacing the character at
	 * index with c
	 * 
	 * for example
	 * 
	 * String foo = "barn";
	 * foo = replaceCharAtIndex(foo, 3, 'd');
	 * 
	 * will create a new string "bard" and change foo to it
	 * 
     */


    public Hangman(String secretWord) {
        this.secretWord = secretWord;
        for (int i = 0; i < secretWord.length(); i++) {
            this.disguisedWord += "?";
        }
    }
    // put your private instance variables here
    private String secretWord;
    private String disguisedWord = "";
    private String guessedLetters = "";
    private int numberOfGuesses = 0;
    private int numberOfIncorrectGuesses = 0;

    public String getSecretWord() {
        return secretWord;
    }

    public String getDisguisedWord() {
        return disguisedWord;
    }

    public String getGuessedLetters() {
        return guessedLetters;
    }

    public int getNumberOfGuesses() {
        return numberOfGuesses;
    }

    public int getNumberOfIncorrectGuesses() {
        return numberOfIncorrectGuesses;
    }

    public void setSecretWord(String secretWord) {
        this.secretWord = secretWord;
    }

    public void setDisguisedWord(String disguisedWord) {
        this.disguisedWord = disguisedWord;
    }

    public void setGuessedLetters(String guessedLetters) {
        this.guessedLetters = guessedLetters;
    }

    public void setNumberOfGuesses(int numberOfGuesses) {
        this.numberOfGuesses = numberOfGuesses;
    }

    public void setNumberOfIncorrectGuesses(int numberOfIncorrectGuesses) {
        this.numberOfIncorrectGuesses = numberOfIncorrectGuesses;
    }

    public boolean isFound() {
        return secretWord.equalsIgnoreCase(disguisedWord);
    }

    /* guesses if c is in the secret word.
	 * if it is, changes all indices the disguised word to c where there is a 
	 * matching character in the secret word
	 * 
	 * Example:
	 * if our secret word is        "banana", 
	 * our disguised word starts as "??????"
	 * If someone calls makeGuess('a'), then makeGuess changes the disguised 
	 * word to "?a?a?a"
	 * Calling makeGuess('n') would change the disguised word to "?anana"
	 * 
     */
    public boolean makeGuess(char guess) {

        String newString = "";
        numberOfGuesses++;
        guessedLetters += guess;
        for (int i = 0; i < secretWord.length(); i++) {
            
          

            if (guess == secretWord.charAt(i)) {
                newString += guess;
            } else {
                newString += disguisedWord.charAt(i);
            }
        }
        if (!newString.equalsIgnoreCase(disguisedWord)) {
            disguisedWord = newString;
            return true;
        } else {
            System.out.println("Incorrect Guess!");

            numberOfIncorrectGuesses++;
            return false;
        }
    }
}
