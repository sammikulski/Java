
package MovieRating;
import java.util.Scanner;

/**
 *
 * @author sammikulski
 */
public class Test3 {
   
    
    
    public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    MovieRating Movie1 = new MovieRating(); 

 
 
    System.out.println("Please enter the name of the movie: ");
    Movie1.setName(input.nextLine());
  
    System.out.println("Please enter the rating of the movie (G, PG, PG13, R, NR) :");
    Movie1.setRating(input.nextLine());
    System.out.println("Please enter 5 ratings for this movie (1-5 Stars) :");
    for (int i = 0; i<5; i++) {
    Movie1.addRating(input.nextInt() );

    }
    Movie1.finalOutput();
   
    System.out.println();
    MovieRating Movie2 = new MovieRating();
    System.out.println("Please enter the name of another movie: ");
    Movie2.setName(input.nextLine());
    Movie2.setName(input.nextLine());
    System.out.println("Please enter the rating of the movie (G, PG, PG13, R, NR) :");
    Movie2.setRating(input.nextLine());
    System.out.println("Please enter 5 ratings for this movie (1-5 Stars) :");
    for (int i = 0; i<5; i++) {
    Movie2.addRating(input.nextInt() );
}
    Movie2.finalOutput();
}
}
  

