
package MovieRating;

/**
 *
 * @author sammikulski
 */
public class MovieRating {
    	//private instance variables
        private String name;
	private String rating;
        private int num1 = 0;
        private int num2 = 0;
        private int num3 = 0;
        private int num4 = 0;
        private int num5 = 0;

                      
    //setters for variables to be used as objects in other classes
    public void setName(String name) {
        this.name = name;
    }
    public void setRating(String rating) {
        this.rating = rating;
    }
        //gettersfor variables to be used as objects in other classes
    public double getTotalReview() {
        return  num1+num2+num3+num4+num5;
    }
    public String getName() {
        return name;
    }
    public String getRating() {
        return rating;
    }
    
    //Formula to get the Average review
    //Takes the number of each stars, multiplies it by the value of stars 
    //(number of 2 star ratings times 2 stars = 4 total stars)
    public double getAverageReview() {
        return  (int) Math.round( ( (num1 * 1) + (num2 * 2) + (num3 * 3) + (num4 * 4) + (num5 * 5) ) / (getTotalReview()));
    }
    //Takes input (a rating) from scanner and increments the value by 1
    //If number is not between 1 and 5, it is ignored
    public void addRating(int stars)
	{
		switch (stars)
		{
			case 1: 
				num1++;
				break;
			case 2: 
				num2++;
				break;
			case 3: 
				num3++;
				break;
			case 4: 
				num4++;
				break;
			case 5: 
				num5++;
				break;
                        default: 
				System.out.println("A value other then 1,2,3,4, or 5 was entered for Review.");
				break;        

		}
	}
    //The end output that gets the Name, Rating and Average Review for each movie 
    public void finalOutput() {
    System.out.println("Name of Movie: " + getName());  
    System.out.println("Rating of Movie: " + getRating());
    System.out.println("Average Review of Movie " + getAverageReview() + " stars");
    System.out.println("This movie has " + "'"+num1+"'" + " 1 star review(s).");
    System.out.println("This movie has " + "'"+num2+"'" + " 2 star review(s).");
    System.out.println("This movie has " + "'"+num3+"'" + " 3 star review(s).");
    System.out.println("This movie has " + "'"+num4+"'" + " 4 star review(s).");
    System.out.println("This movie has " + "'"+num5+"'" + " 5 star review(s).");
    }

    
    
}

