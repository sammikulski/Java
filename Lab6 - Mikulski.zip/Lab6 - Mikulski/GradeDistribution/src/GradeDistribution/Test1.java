package GradeDistribution;

import java.util.Scanner;

/**
 *
 * @author sammikulski
 */
public class Test1 {
    
public static void main(String[] args) {

    Scanner input = new Scanner (System.in);
    
    //Declaring new GradeDistribution object
    GradeDistribution newGrade = new GradeDistribution();
    System.out.println ("Please enter the number of A's: ");
        newGrade.setNumA(input.nextInt());
    System.out.println ("Please enter the number of B's: ");
        newGrade.setNumB(input.nextInt());
    System.out.println ("Please enter the number of C's: ");
        newGrade.setNumC(input.nextInt());
    System.out.println ("Please enter the number of D's: ");
        newGrade.setNumD(input.nextInt());
    System.out.println ("Please enter the number of F's: ");
        newGrade.setNumF(input.nextInt());
    System.out.println();    
    System.out.println("The total number of grades inputted is: " + newGrade.totalGrades());

    System.out.println("The percentage of A's is: "+ newGrade.percentA() + "%");
    System.out.println("The percentage of B's is: "+ newGrade.percentB() + "%");
    System.out.println("The percentage of C's is: "+ newGrade.percentC() + "%");
    System.out.println("The percentage of D's is: "+ newGrade.percentD() + "%");
    System.out.println("The percentage of F's is: "+ newGrade.percentF() + "%");
    
    newGrade.drawGraph();
}
}


