package GradeDistribution;
/**
 *
 * @author sammikulski
 */
public class GradeDistribution {
    	// Private instance variables
	private int numA;
	private int numB;
	private int numC;
        private int numD;
	private int numF;
        private double percentA;
        private double percentB;
        private double percentC;
        private double percentD;
        private double percentF;
        
//Setters for variables to be used as objects in other class
    public void setPercentA(double percentA) {
        this.percentA = percentA;
    }
    public void setPercentB(double percentB) {
        this.percentB = percentB;
    }
    public void setPercentC(double percentC) {
        this.percentC = percentC;
    }
    public void setPercentD(double percentD) {
        this.percentD = percentD;
    }
    public void setPercentF(double percentF) {
        this.percentF = percentF;
    }
     public void setNumA(int numA) {
        this.numA = numA;
    }
    public void setNumB(int numB) {
        this.numB = numB;
    }
    public void setNumC(int numC) {
        this.numC = numC;
    }
    public void setNumD(int numD) {
        this.numD = numD;
    }
    public void setNumF(int numF) {
        this.numF = numF;
    }    
//Getters for variables to be used as objects in other class
    public double getPercentA() {
        return percentA;
    }
    public double getPercentB() {
        return percentB;
    }
    public double getPercentC() {
        return percentC;
    }
    public double getPercentD() {
        return percentD;
    }
    public double getPercentF() {
        return percentF;
    }
    public int getNumA() {
        return numA;
    }
    public int getNumB() {
        return numB;
    }
    public int getNumC() {
        return numC;
    }
    public int getNumD() {
        return numD;
    }
    public int getNumF() {
        return numF;
    }
   
	
//to get total grades, we take the sum of the number of A's, B's, C's, D's and F's entered
        public double totalGrades(){
           
        return numA+numB+numC+numD+numF;
	}
        
//to get the percent of each letter grade, we first take the num of A's, B's, C's, D's or F's
//and multiply it by 100 (to get percent as a whole number) and then divide it by the total number of grades
//We need a double so that it can be rounded to the nearest whole number, so that the percentages will be accurate       
//We then use (int) to convert the double to an integer
	public int percentA (){
		return (int) Math.round ((numA*100) / totalGrades()); 
	}
	public int percentB (){ 
		return (int) Math.round ((numB*100) / totalGrades()); 
	}
	public int percentC (){ 
		return (int) Math.round ((numC*100) / totalGrades()); 
	}
	public int percentD (){ 
		return (int) Math.round ((numD*100) / totalGrades()); 
	}
	public int percentF (){ 
		return (int) Math.round ((numF*100) / totalGrades()); 
	}

//Print statements to draw the number line
	public void drawGraph(){
        System.out.println("     0    10    20   30   40   50   60   70   80   90  100");
        System.out.println("     |    |     |    |    |    |    |    |    |    |   |");
 
//In each of these loops, it takes the percentage of the letter grade and divides by 2, then adds prints a *
//So that 1 * = 2 percentage points
        System.out.print("A's: ");
        for(int i = 0; i <= ((int) Math.round (percentA() / 2)); i++)
            System.out.print("*");
        System.out.print(" A");
        System.out.println();
        
        System.out.print("B's: ");
        for(int i = 0; i <= ((int) Math.round (percentB() / 2)); i++)
            System.out.print("*");
            System.out.print(" B");
        System.out.println();
        
        System.out.print("C's: ");
        for(int i = 0; i <= ((int) Math.round (percentC() / 2)); i++) 
            System.out.print("*");
        System.out.print(" C");
        System.out.println();
        
        System.out.print("D's: ");
        for(int i = 0; i <= ((int) Math.round (percentD() / 2)); i++)
            System.out.print("*");
        System.out.print(" D");
        System.out.println();
        
        System.out.print("F's: ");
        for(int i = 0; i <= ((int) Math.round (percentF() / 2)); i++)
            System.out.print("*");
        System.out.print(" F");
        System.out.println();
    }
		
	}

