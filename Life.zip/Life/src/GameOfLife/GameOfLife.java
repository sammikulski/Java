package GameOfLife;

import java.util.Random;

/**
 *
 * @author sammikulski
 */
public class GameOfLife {

    private static final int row = 4;
    private static final int col = 4;

    public static void main(String[] args) {

        Random randGen = new Random();

        //this changes how many times it will run
        for (int x = 0; x < 1; x++) {
            //buffer will act as overflow, but in the end,
            //always prints the final int dimensions
            boolean[][] nextBoard = new boolean[row + 2][col + 2];
            boolean[][] currBoard = new boolean[col + 2][col + 2];

            for (int i = 1; i <= currBoard.length - 1; i++) {
                for (int j = 1; j <= currBoard.length - 1; j++) {
                    currBoard[i][j] = false;
                    nextBoard[i][j] = false;
                }
            }
            for (int k = 1; k < currBoard.length - 1; k++) {
                for (int l = 1; l < currBoard.length - 1; l++) {
                    int random = randGen.nextInt(10);
                    if (random == 2) {
                        currBoard[k][l] = true;
                    }
                    if (random != 2) {
                        currBoard[k][l] = false;
                    }
                }
            }

            copyBoard(currBoard, nextBoard);
            newValueChange(currBoard, nextBoard);
            printBoard(currBoard);
            printBoard(nextBoard);

            System.out.println(countLiveNeighbors(1, 2, nextBoard));

        }
    }

    //counts neighboring cells in array
    private static int countLiveNeighbors(int row, int col, boolean[][] board) {
        int count = 0;
        if (board[row - 1][col]) {
            count++;
        }
        if (board[row + 1][col]) {
            count++;
        }
        if (board[row][col - 1]) {
            count++;
        }
        if (board[row][col + 1]) {
            count++;
        }
        if (board[row - 1][col - 1]) {
            count++;
        }
        if (board[row - 1][col + 1]) {
            count++;
        }
        if (board[row + 1][col - 1]) {
            count++;
        }
        if (board[row + 1][col + 1]) {
            count++;
        }
        return count;

    }

    //assigns new values in arrays, depending on neighbor count
    private static void newValueChange(boolean[][] currBoard, boolean[][] nextBoard) {
        for (int f = 1; f < currBoard.length - 1; f++) {
            for (int p = 1; p < currBoard.length - 1; p++) {
                if (countLiveNeighbors(f, p, currBoard) == 3) {
                    nextBoard[f][p] = true;
                }
                if (countLiveNeighbors(f, p, currBoard) < 2) {
                    nextBoard[f][p] = false;
                }
                if (countLiveNeighbors(f, p, currBoard) > 3) {
                    nextBoard[f][p] = false;
                }
                if (countLiveNeighbors(f, p, currBoard) == 2) {
                    nextBoard[f][p] = true;

                }
            }
        }
    }
    //copies current board to new

    private static void copyBoard(boolean[][] currBoard, boolean[][] nextBoard) {
        for (int y = 1; y < currBoard.length - 1; y++) {
            for (int z = 1; z < currBoard.length - 1; z++) {
                nextBoard[y][z] = currBoard[y][z];
            }
        }
    }

    
    private static int countLiveNeighborsBAD(int row, int col, boolean[][] board) {
        int count = 0;
        if (row - 1 >= 0 && col - 1 >= col && board[row - 1][col]) {
            count++;
        }
        if (row - 1 >= 0 && col - 1 >= col && board[row + 1][col]) {
            count++;
        }
        if (row - 1 >= 0 && col - 1 >= col && board[row][col - 1]) {
            count++;
        }
        if (row - 1 >= 0 && col - 1 >= col && board[row][col + 1]) {
            count++;
        }
        if (row + 1 < row && col + 1 < col && board[row - 1][col - 1]) {
            count++;
        }
        if (row + 1 < row && col + 1 < col && board[row - 1][col + 1]) {
            count++;
        }
        if (row + 1 < row && col + 1 < col && board[row + 1][col - 1]) {
            count++;
        }
        if (row + 1 < row && col + 1 < col && board[row + 1][col + 1]) {
            count++;
        }
        return count;

    }
//prints X for live and ^ for dead cells
    private static void printBoard(boolean[][] nextBoard) {
        for (int a = 1; a <= row; a++) {
            for (int b = 1; b <= col; b++) {
                if (nextBoard[a][b]) {
                    System.out.print("[X]");
                } else {
                    System.out.print("[^ ]");
                }
            }
            System.out.println("");
        }
        System.out.println("");
    }
}
